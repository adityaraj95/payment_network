<header id="header">
  <div id="logo-group" style="background:#ffffff;">
    <span id="logo"> <img src="img/logo.png" alt="<?PHP// echo SITE_TITLE; ?>"> </span>
  </div>
  <div class="pull-right">
    <div id="hide-menu" class="btn-header transparent pull-right"> <span> <a href="javascript:void(0);" data-action="toggleMenu" title="Collapse Menu"><i class="fa fa-reorder"></i></a> </span> </div>
    <div id="logout" class="btn-header transparent pull-right"> <span> <a href="logout.php" title="Sign Out" data-action="userLogout" data-logout-msg="You can improve your security further after logging out by closing this opened browser"><i class="fa fa-sign-out"></i></a> </span> </div>   
  </div>
</header>