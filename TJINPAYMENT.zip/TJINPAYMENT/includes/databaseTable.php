<?PHP
	define("TABLE_PREFIX", "");			
	
	define("ADMIN_MASTER",  TABLE_PREFIX."admin");								//manage admin settings
	define("Retailers",  TABLE_PREFIX."retailers");									//manage Retailers
	define("Distributors",  TABLE_PREFIX."distributor");										//manage Distributors
/*	define("QUESTIONS",  TABLE_PREFIX."questions");								//manage questions
	define("USERS",  TABLE_PREFIX."users");										//manage users
	define("ANSWERS",  TABLE_PREFIX."answers");									//manage answers
	define("FORMS",  TABLE_PREFIX."forms");										//manage forms
	define("SIFT",  TABLE_PREFIX."sift");										//manage sift*/



?>