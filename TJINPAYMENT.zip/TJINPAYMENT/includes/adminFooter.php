<div class="page-footer">
  <div class="row">
    <div class="col-xs-12 col-sm-6" style="width:100%"><span class="txt-color-white"><?PHP echo SITE_TITLE; ?> &copy; <?PHP echo date('Y'); ?></span> </div>
  </div>
</div>